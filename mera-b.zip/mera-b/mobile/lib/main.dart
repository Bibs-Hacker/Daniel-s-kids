import 'package:flutter/material.dart';
import 'theme.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const PinkApp());
}

class PinkApp extends StatelessWidget {
  const PinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mera-B',
      theme: pinkTheme,
      home: const LoginScreen(),
    );
  }
}
