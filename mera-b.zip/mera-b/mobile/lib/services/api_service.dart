import 'package:http/http.dart' as http;
import 'dart:convert';

class ApiService {
  final String baseUrl;
  ApiService(this.baseUrl);

  Future<Map<String,dynamic>> requestOtp(String phone) async {
    final res = await http.post(Uri.parse('\$baseUrl/auth/request_otp'), body: json.encode({'phone': phone}), headers: {'Content-Type':'application/json'});
    return json.decode(res.body);
  }

  Future<Map<String,dynamic>> verifyOtp(String phone, String code) async {
    final res = await http.post(Uri.parse('\$baseUrl/auth/verify_otp'), body: json.encode({'phone': phone, 'code': code}), headers: {'Content-Type':'application/json'});
    return json.decode(res.body);
  }
}
