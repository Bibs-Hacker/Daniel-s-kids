import 'package:socket_io_client/socket_io_client.dart' as IO;

class SocketService {
  IO.Socket? socket;
  void connect(String baseUrl, String token) {
    socket = IO.io(baseUrl, IO.OptionBuilder().setTransports(['websocket']).build());
    socket!.onConnect((_) {
      socket!.emit('auth', { 'token': token });
    });
  }
  void sendMessage(Map payload) {
    socket?.emit('message.send', payload);
  }
}
