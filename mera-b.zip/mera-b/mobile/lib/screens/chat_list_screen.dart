import 'package:flutter/material.dart';
import 'chat_screen.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dummyConversations = [
      {"name": "Merab", "lastMessage": "See you soon ❤️"},
      {"name": "Brian", "lastMessage": "How’s coding going?"},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text("Mera-B")),
      body: ListView.builder(
        itemCount: dummyConversations.length,
        itemBuilder: (context, index) {
          final conv = dummyConversations[index];
          return ListTile(
            title: Text(conv["name"]!),
            subtitle: Text(conv["lastMessage"]!),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => ChatScreen(name: conv["name"]!),
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.chat),
      ),
    );
  }
}
