import 'package:flutter/material.dart';

final ThemeData pinkTheme = ThemeData(
  primaryColor: Colors.pink,
  scaffoldBackgroundColor: Colors.white,
  colorScheme: ColorScheme.light(
    primary: Colors.pink,
    secondary: Colors.pinkAccent,
  ),
  appBarTheme: AppBarTheme(
    backgroundColor: Colors.pink,
    foregroundColor: Colors.white,
    elevation: 0,
  ),
  floatingActionButtonTheme: FloatingActionButtonThemeData(
    backgroundColor: Colors.pinkAccent,
  ),
);
