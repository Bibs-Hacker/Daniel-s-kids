# Mera-B (Pink WhatsApp-like clone)

This archive contains a demo WhatsApp-like app (backend + Flutter mobile skeleton).
The project is intentionally simplified so you can run it locally quickly.

## Backend
- Simple Node.js + Express + Socket.IO server (in-memory demo stores)
- Run:
  ```
  cd backend
  npm install
  node src/index.js
  ```
- Server runs on http://localhost:4000

## Mobile
- Flutter app skeleton (pink theme)
- Run:
  ```
  cd mobile
  flutter pub get
  flutter run
  ```

## Notes
- This demo uses in-memory stores for users, conversations, and messages.
- For production you should add Postgres/Redis, implement persistent storage, and integrate Signal Protocol for E2EE.
