const express = require('express');
const router = express.Router();
// Mock OTP - for production replace with Twilio or other provider

// Request OTP (mock)
router.post('/request_otp', (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'phone required' });
  // In production generate & send OTP. Here we'll accept any code '1234'
  return res.json({ ok: true, message: 'OTP sent (mock)', testCode: '1234' });
});

router.post('/verify_otp', (req, res) => {
  const { phone, code, device_id } = req.body;
  if (!phone || !code) return res.status(400).json({ error: 'phone and code required' });
  if (code !== '1234') return res.status(401).json({ error: 'invalid code (use 1234 in mock)' });
  // Return simple token (INSECURE: for demo only)
  const token = Buffer.from(phone).toString('base64');
  return res.json({ ok: true, token, phone });
});

module.exports = router;
