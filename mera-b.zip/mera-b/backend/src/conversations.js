const express = require('express');
const router = express.Router();
const convs = {}; // in-memory demo

router.post('/', (req, res) => {
  const { members, type } = req.body;
  if (!members || !Array.isArray(members)) return res.status(400).json({ error: 'members[] required' });
  const id = 'conv_' + Date.now();
  convs[id] = { id, members, type: type||'direct', created_at: new Date().toISOString() };
  res.json(convs[id]);
});

router.get('/', (req, res) => {
  // Return all convs where the auth'd user is a member (demo)
  const auth = req.headers.authorization;
  const phone = auth ? Buffer.from(auth.replace('Bearer ','') , 'base64').toString('utf8') : null;
  const list = Object.values(convs).filter(c => !phone || c.members.includes(phone));
  res.json(list);
});

module.exports = router;
