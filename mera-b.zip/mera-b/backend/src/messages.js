const express = require('express');
const router = express.Router();
const msgs = {}; // { convId: [msg...] }

router.get('/:convId', (req, res) => {
  const convId = req.params.convId;
  const list = msgs[convId] || [];
  res.json(list);
});

router.post('/:convId', (req, res) => {
  const convId = req.params.convId;
  const { sender, type='text', body } = req.body;
  if (!sender || !body) return res.status(400).json({ error: 'sender and body required' });
  const m = { id: 'm_'+Date.now(), conversation_id: convId, sender, type, body, created_at: new Date().toISOString(), status: {} };
  msgs[convId] = msgs[convId] || [];
  msgs[convId].push(m);
  res.json(m);
});

module.exports = router;
