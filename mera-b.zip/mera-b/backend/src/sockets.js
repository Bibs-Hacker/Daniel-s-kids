module.exports = function(io){
  const online = {}; // phone -> socketId
  io.on('connection', (socket) => {
    console.log('socket connected', socket.id);
    socket.on('auth', (data) => {
      // data: { token }
      try {
        const phone = Buffer.from(data.token, 'base64').toString('utf8');
        online[phone] = socket.id;
        socket.phone = phone;
        io.emit('presence', { phone, online: true });
      } catch(e){ console.warn('bad token'); }
    });

    socket.on('message.send', (payload) => {
      // payload: { conversation_id, sender, body }
      console.log('message.send', payload);
      // persist in-memory? here we emit to all (demo)
      io.emit('message', payload);
    });

    socket.on('disconnect', () => {
      if (socket.phone) {
        delete online[socket.phone];
        io.emit('presence', { phone: socket.phone, online: false });
      }
    });
  });
};
