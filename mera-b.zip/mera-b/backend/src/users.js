const express = require('express');
const router = express.Router();

// Simple in-memory store for demo (replace with DB)
const users = {};

router.get('/me', (req, res) => {
  // In demo, token is base64(phone)
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'missing auth' });
  const phone = Buffer.from(auth.replace('Bearer ','') , 'base64').toString('utf8');
  let user = users[phone];
  if (!user) {
    user = { id: phone, phone, display_name: phone, profile_photo_url: null, created_at: new Date().toISOString() };
    users[phone] = user;
  }
  res.json(user);
});

router.put('/me', (req, res) => {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'missing auth' });
  const phone = Buffer.from(auth.replace('Bearer ','') , 'base64').toString('utf8');
  const user = users[phone];
  if (!user) return res.status(404).json({ error: 'not found' });
  const { display_name, profile_photo_url } = req.body;
  if (display_name) user.display_name = display_name;
  if (profile_photo_url) user.profile_photo_url = profile_photo_url;
  res.json(user);
});

module.exports = router;
